## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(soils)
head(washi_data, 5) |> knitr::kable()
head(data_dictionary, 5) |> knitr::kable()

## -----------------------------------------------------------------------------
dplyr::glimpse(washi_data)

## -----------------------------------------------------------------------------
dplyr::glimpse(data_dictionary)

## ----load-data, eval=FALSE----------------------------------------------------
# # EDIT: Add your cleaned lab data to the data folder, using 'washi-data.csv' as
# # a template.
# 
# # Load lab results
# data <- read.csv(
#   here::here("data/my-data.csv"),
#   check.names = FALSE,
#   encoding = "UTF-8",
#   strip.white = TRUE
# )

## ----load-dictionary, eval=FALSE----------------------------------------------
# # EDIT: Add your data dictionary to the data folder, using 'data-dictionary.csv'
# # as a template.
# 
# # Load data dictionary
# dictionary <- read.csv(
#   here::here("data/my-dictionary.csv"),
#   check.names = FALSE,
#   # Set encoding for using subscripts, superscripts, special characters
#   encoding = "UTF-8",
#   strip.white = TRUE
# )

## ----tidy-long, eval=FALSE----------------------------------------------------
# # EDIT: `washi_data` example has soil measurements in columns 12 - 42. Replace
# # this column range with the column indices of the soil measurements in your
# # dataset.
# 
# # Tidy data into long format and join with data dictionary
# results_long <- data |>
#   dplyr::mutate(
#     dplyr::across(
#       # EDIT: replace with the column range of your soil measurements
#       12:26,
#       as.numeric
#     )
#   ) |>
#   tidyr::pivot_longer(
#     # EDIT: replace with the column range of your soil measurements
#     cols = 12:26,
#     names_to = "measurement"
#   )

## ----data-validation-changed, eval=FALSE--------------------------------------
# # OPTIONAL EDIT: If you have extra columns in `data`, add them to this vector.
# required_cols <- c(
#   "year",
#   "sample_id",
#   "farm_name",
#   "producer_id",
#   "field_name",
#   "field_id",
#   "county",
#   "crop",
#   "longitude",
#   "latitude",
#   "texture",
#   "tillage"
# )
# 
# # Check all column names in `data` are in the `required_cols` vector or
# # `column_name` column of `dictionary`.
# testthat::expect_in(names(data), c(required_cols, dictionary$column_name))

