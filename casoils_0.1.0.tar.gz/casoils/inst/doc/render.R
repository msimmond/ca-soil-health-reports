## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
# # EDIT: Replace `washi-data.csv` with the name of the same dataset used in
# # 01_producer-report.qmd.
# data <- read.csv(
#   here::here("data/washi-data.csv"),
#   check.names = FALSE,
#   encoding = "UTF-8"
# ) |>
#   dplyr::filter(producer_id %in% c("WUY05", "RHM05", "ENR07"))

