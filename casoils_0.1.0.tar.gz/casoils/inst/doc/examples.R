## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo=FALSE, out.width="100%"---------------------------------------------
knitr::include_url(
  "https://soils-example-html.netlify.app/", height = "500px")

## ----echo=FALSE, out.width="100%"---------------------------------------------
knitr::include_url(
  "https://soils-spanish-example.netlify.app/", height = "500px")

