## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval=FALSE---------------------------------------------------------------
# sections <- purrr::map_chr(measurement_groups, \(group) {     # <1>
#   knitr::knit_child(
#     input = "02_section-template.qmd",
#     envir = rlang::env(),
#     quiet = TRUE
#   )
# })
# 
# cat(sections, sep = "\n")                                     # <2>

