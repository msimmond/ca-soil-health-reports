# create_soils returns appropriate error

    ! `path` must be provided.
    i Where do you want to create this project?
    i For example, `create_soils(path = 'path/to/my/directory')`.

